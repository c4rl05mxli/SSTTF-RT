#include "dialog.h"
#include "ui_dialog.h"
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QDebug>
#include <QMessageBox>
#include <QtCore>
#include <QDir>
#include <QFile>
#include <QSettings>
#include <QTextStream>
#include <QNetworkInterface>
#include <QFontDatabase>



QString namefile="";
bool    debug_bool=false;


Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
    {
        ui->setupUi(this);


    /*Set image Background*/
        QPixmap bkgnd(":/img/SSTTF");
        //    bkgnd = bkgnd.scaled(this->size(), Qt::IgnoreAspectRatio);
        QPalette palette;
        palette.setBrush(QPalette::Background, bkgnd);
        this->setPalette(palette);

    /*Set Label background and foreground colors*/
        QPalette sample_palette;
        sample_palette.setColor(QPalette::Window, Qt::black);
        sample_palette.setColor(QPalette::WindowText, Qt::green);

        ui->lblTime->setAutoFillBackground(false);
        ui->lblTime->setPalette(sample_palette);

        ui->lblDate->setAutoFillBackground(false);
        ui->lblDate->setPalette(sample_palette);

        ui->lblPosition->setAutoFillBackground(false);
        ui->lblPosition->setPalette(sample_palette);

        ui->lblStatus->setAutoFillBackground(false);
        ui->lblStatus->setPalette(sample_palette);

        ui->lbLCD->setAutoFillBackground(false);
        ui->lbLCD->setPalette(sample_palette);

        ui->lbLCD_P->setAutoFillBackground(false);
        ui->lbLCD_P->setPalette(sample_palette);

    /*Set Font type*/
        QFontDatabase::addApplicationFont(":/fnt/ATOMICCLOCKRADIO.TTF");
        QFont font = QFont("Atomic Clock Radio", 80, 1);
        ui->lblTime->setFont(font);
        font = QFont("Atomic Clock Radio", 30, 1);
        ui->lblDate->setFont(font);
        font = QFont("Atomic Clock Radio", 20, 1);
        ui->lblPosition->setFont(font);
        ui->lblStatus->setFont(font);
        font = QFont("Atomic Clock Radio", 30, 1);
        ui->lbLCD->setFont(font);
        ui->lbLCD_P->setFont(font);

        /* Make the button "invisible" */

        QPixmap pixmap(":/img/FN.png");
        QIcon ButtonIcon(pixmap);
        ui->btnFuegoNuevo->setIcon(ButtonIcon);
        ui->btnFuegoNuevo->setIconSize(pixmap.rect().size());
        ui->btnFuegoNuevo->setFixedSize(pixmap.rect().size());


        /* hide controls*/
        ui->btnConfig->setVisible(false);
        ui->btnReset->setVisible(false);
        ui->btnReboot->setVisible(false);
        ui->btnSendPosition->setVisible(false);
        ui->btnStartPoll->setVisible(false);
        ui->btnStopPoll->setVisible(false);
        ui->btnSurvey->setVisible(false);
        ui->txtDBG->setVisible(false);


       QList<QNetworkInterface> interfaces = QNetworkInterface::allInterfaces();
       for(int i=0; i<interfaces.count(); i++)
       {
            QList<QNetworkAddressEntry> entries = interfaces.at(i).addressEntries();
                for(int j=0; j<entries.count(); j++)
                {

                    if(entries.at(j).ip().protocol() == QAbstractSocket::IPv4Protocol)
                    {
                       if (entries.at(j).ip().toString() != "127.0.0.1")
                        {

                            IPv4=entries.at(j).ip().toString();
                            SubMask=entries.at(j).netmask().toString();
                            Gateway=entries.at(j).broadcast().toString();

                            qDebug() << "Interface [" << QString::number(i+1) << "]" << endl;
                            qDebug() << "IP:" << IPv4 << endl;
                            debug=debug + "IP [" + QString::number(i+1) +"] = " + IPv4 + "\r\n";
                            ui->txtDBG->setText(debug);
                            qDebug() << "MASK" << SubMask << endl;
                            qDebug() << "Gateway" << Gateway <<endl;

                        }
                     }

                }
       }

// Directory Creation
        path = QCoreApplication::applicationDirPath(); //working directory to path variable
        qDebug() << path << endl;
        config_path=path + "/config";
        data_path=path + "/data" ;

        QDir  config(config_path);

        if (config.exists())
        {
            //qDebug() << "true" << config << endl;
        }
        else
        {
         //   qDebug() << "false" << config << endl;
            config.mkdir(config_path);
        }
        QDir  data(data_path);
        if (data.exists())
        {
          //  qDebug() << "true" << data << endl;
        }
        else
        {
          //  qDebug() << "false" << data << endl;
            data.mkdir(data_path);
        }

// Log file creation
QFile file(config_path + "/log.txt");

if (!file.open(QFile::WriteOnly | QFile::Append))
{
    qDebug() << "File not open" <<endl;
}
    QTextStream out(&file);
    QString text= "Application Started";
    out << QDate::currentDate().toString(Qt::ISODate) <<"/" << QTime::currentTime().toString(Qt::ISODate) << " " << text << endl;
    file.flush();
    file.close();
    //
   //ReadSettings(); //leo dos veces, la primera lo creo si no existe
   // ReadSettings();


      ReadSettings();

      GPS= new QSerialPort(this); //creo un nuevo objeto de puerto serial
      serialBuffer ="";
      serialData="";
      data_value=0.0;     // inicializo variables

      TIC= new QSerialPort(this); //creo un nuevo objeto de puerto serial
      TIC_Buffer="";
      TIC_parsed_data="";
      TIC_data_value=0.0;

      /*
       *  Open and configure the GPS port if available
       */
      if(GPS_is_available){
          //Serial Port GPS
          qDebug() << "Found the GPS" << GPS_port_name << endl;
          GPS->setPortName(GPS_port_name);
          GPS->open(QSerialPort::ReadWrite); //Read and Write Device, Unbuffered
          GPS->setBaudRate(QSerialPort::Baud9600);
          GPS->setDataBits(QSerialPort::Data8);
          GPS->setFlowControl(QSerialPort::NoFlowControl);
          GPS->setParity(QSerialPort::NoParity);
          GPS->setStopBits(QSerialPort::OneStop);
          QObject::connect(GPS, SIGNAL(readyRead()), this, SLOT(readSerialGPS()));
      }else{
          qDebug() << "Couldn't find the correct port for the GPS.\n";
      }


      /*
       *  Open and configure the TIC port if available
       */
      if(TIC_is_available){
           //Serial Port TIC
           qDebug() << "Found the TIC" << TIC_port_name << endl;
           TIC->setPortName(TIC_port_name);
           TIC->open(QSerialPort::ReadOnly); //Read and Write Device, Unbuffered
           TIC->setBaudRate(QSerialPort::Baud115200);
           TIC->setDataBits(QSerialPort::Data8);
           TIC->setFlowControl(QSerialPort::NoFlowControl);
           TIC->setParity(QSerialPort::NoParity);
           TIC->setStopBits(QSerialPort::OneStop);
           QObject::connect(TIC, SIGNAL(readyRead()), this, SLOT(readSerialTIC()));
      }else{
          qDebug() << "Couldn't find the correct port for the TIC.\n";
      }

      debug=debug + "GPS:" + GPS_port_name + "\r\n";
      debug=debug + "TIC:" + TIC_port_name + "\r\n";
      ui->txtDBG->setText(debug);

// inicializo mosquitto
      mosquitto=new QProcess(this);

}

Dialog::~Dialog()
{
    if(GPS->isOpen()){
           GPS->close(); //    Close the serial port if it's open.
       }
    if(TIC->isOpen()){
           TIC->close(); //    Close the serial port if it's open.
       }
    delete ui;
}

void Dialog::readSerialGPS()
{

    QByteArray _STX("@@");
    QByteArray _ETX("\r\n");
    QByteArray Ha("Ha");
    QByteArray Hn("Hn");
    QByteArray Bb("Bb");
  //  QByteArray Cb("Cb"); //almanac

    // Respuestas de la secuencia de inicio del GPS
    QByteArray Cf("Cf");    // Set to Defaults
    QByteArray Sc("Sc");    // Set Constellation Mode to GPS Only
    QByteArray St("St");    // Set sets time & 1PPS alignment source to UTC(USNO)

    QByteArray Gb("Gb");    // Set DateTime to GPS   // DEsactivado
    QByteArray Gc("Gc");    // Set PPS to one sat only
    //QByteArray Ch("Ch");    // Almanac input
    QByteArray As("As");    // Position Hold input
    QByteArray Gd("Gd");    // Set Position Hold
    QByteArray Ay("Ay");    // Time Offset Command
    QByteArray Az("Az");    // Cable Delay Correction
    QByteArray Ge("Ge");    // Set Enable T-RAIM


    QByteArray  _CMD;
    qint16     STX=0;
    qint16     ETX=0;
    quint16 dataSize = 0;
    quint16 cmd_lenght=0;

    dataSize = GPS->bytesAvailable(); //determino numero de caracteres en el puerto
   //qDebug() <<   "GPS Bytes Available: " << dataSize << "\n";
    serialData = serialData + GPS-> read(dataSize); //leo el numero de caracteres
   //qDebug() << serialData <<endl;
   //qDebug() << serialData.size() << endl;



    if (response_lenght==0)
    {
        if(serialData.size()>=6)
        {
           //Find STX (@@)
           STX = serialData.indexOf(_STX,0);
           if(STX >= 0)
           {
        //   qDebug()    <<  "Index of STX"  <<  STX;
           _CMD=serialData.mid(STX+2,2);
          // qDebug()  << "CMD: " << _CMD  ;

           if (_CMD==Ha)
           {
               cmd_lenght=154;
           }

           if (_CMD==Hn)
           {
               cmd_lenght=78;
           }

           if (_CMD==Bb)
           {
               cmd_lenght=92;
           }



           ETX = serialData.indexOf(_ETX,STX+cmd_lenght-4);


       //     qDebug()    <<  "Index of ETX"  << ETX;

           }




         //   qDebug()    <<  "Index of ETX"  <<  serialData.indexOf(_ETX,0);






              if (ETX > 0)
              {
                  if (_CMD==Ha)
                  {
                  Ha_Data(serialData.mid(STX,ETX+2));
                  serialData.remove(STX,ETX+2);
                  CMD_Ha=true;
                    //Dialog::update_Data();
                  }

                  if (_CMD==Hn)
                  {
                  Hn_Data(serialData.mid(STX,ETX+2));
                  serialData.remove(STX,ETX+2);
                  CMD_Hn=true;
                    //Dialog::update_Data();
                  }

                  if (_CMD==Bb)
                  {
                  Bb_Data(serialData.mid(STX,ETX+2));
                  serialData.remove(STX,ETX+2);
                  CMD_Bb=true;
                   // Dialog::update_Data();
                  }

                  if(CMD_Ha & CMD_Hn & CMD_Bb)
                  {
                   Dialog::update_Data();
                   CMD_Ha=false;
                   CMD_Hn=false;
                   CMD_Bb=false;
                  }
              }






        }

    }
    else if (serialData.size()>=response_lenght)
    {
     qDebug() << "[" << serialData.size() << "] = " << serialData << endl;



         STX = serialData.indexOf(_STX,0);
         if(STX >= 0)
         {
             _CMD=serialData.mid(STX+2,2);
            //Aqui defino la secuencia de comandos iniciales, esto es muy mal hecho y necesita cambiarse
             if (_CMD==Cf){

                  debug =  "GPS Set to Defaults";
                  qDebug() << debug;
                  ui->txtDBG->setText(debug);

                  serialData.clear();
             }

             if (_CMD==Sc){
                // qDebug() << "Constallation Set to GPS Only" << endl;

                 debug =  "Constallation Set to GPS Only";
                 qDebug() << debug;
                 ui->txtDBG->setText(debug);

                 SetDateTimePPSAlignment();
             }

             if (_CMD==St){
                // qDebug() << "Time & 1PPS aligned to UTC(USNO)" << endl;
                 debug = "Time & 1PPS aligned to UTC(USNO)";
                 qDebug() << debug;
                 ui->txtDBG->setText(debug);

                //TimeMessage();
                 PPSOneSat();
             }

             if (_CMD==Gb){
                 // qDebug() << "GPS Set Date and Time" << endl;
                  debug = "GPS Set Date and Time";
                  qDebug() << debug;
                  ui->txtDBG->setText(debug);
                  PPSOneSat();
             }
             if (_CMD==Gc){
                  //qDebug() << "1PPS Control Message Set to active only when tracking at least one satellite" << endl;

                  debug = "1PPS Control Message Set to active only when tracking at least one satellite";
                  qDebug() << debug;
                  ui->txtDBG->setText(debug);

                  SendPosition();
             }
//             if (_CMD==Ch){
//                  qDebug() << "Almanac Data Input" << endl;
//                 SendPosition();
//             }
             if (_CMD==As){
                //  qDebug() << "Position to Hold Input" << endl;

                  debug = "Position to Hold Input";
                  qDebug() << debug;
                  ui->txtDBG->setText(debug);

                  SendPositionHold();
             }
             if (_CMD==Gd){
                 // qDebug() << "Position Hold Mode" << endl;

                  debug = "Position to Hold Mode";
                  qDebug() << debug;
                  ui->txtDBG->setText(debug);
                  EnableTRAIM();
             }
             if (_CMD==Ay){
                 qDebug()<< "Advanced 1PPS 5ms" << endl;
                // Cable_delay();
             }
             if (_CMD==Az){
                 //qDebug()<< "Cable delay corrected " << QString::number(cable_delay,10) << " ns" << endl;


                // EnableTRAIM();
             }
             if (_CMD==Ge){
                 // qDebug() << "T-RAIM Enabled" << endl;

                  debug = "T-RAIM Enabled";
                  qDebug() << debug;
                  ui->txtDBG->setText(debug);
                  StartPolling();
                 // qDebug() << "GPS Started" << endl;
             }

         }

     response_ready=true;
     serialData.clear();
    }
}

void Dialog::readSerialTIC()
{
     quint16 dataSize = 0;
     qint16     STX=0;
     qint16     ETX=0;

     dataSize = TIC->bytesAvailable(); //determino numero de caracteres en el puerto
     //qDebug() <<  " TIC Bytes = " << dataSize << endl;
     TIC_Data = TIC_Data + TIC-> read(dataSize); //leo el numero de caracteres
     //qDebug() << TIC_Data << endl;

     if(TIC_Data.size()>=16)
       {
           STX = TIC_Data.indexOf(0x02,0);
           if(STX >= 0)
           {
          //  qDebug()    <<  "Index of STX"  <<  STX;


           ETX = TIC_Data.indexOf(0x03,STX);

          if(ETX>0)
          {

            // qDebug()    <<  "Index of ETX"  <<  ETX;

          TIC_Buffer=TIC_Data.mid(STX+1,(ETX-STX)-1);
          count=TIC_Buffer.toDouble();

          count=count*1e9;
          count=count+int_dly+cbl_dly+ref_dly;

          TIC_Data.remove(STX,ETX+1);
           }
           }


       }


}

void Dialog::update_Data()
{
   // Date
    ui->lblTime->setText(GPStime.toString(Qt::ISODate));
    ui->lblDate->setText(GPSdate.toString(Qt::ISODate) + "  " + QString::number(JulianDate(GPSdate))  );
   // Position
    ui->lblPosition->setText(QString::number(latitud, 'g', 10) + "," + QString::number(longitud, 'g', 10)  + "," + QString::number(altitud, 'g', 10) );
   // Status
    ui->lblStatus->setText(QString::number(nvs,10) + "/" + QString::number(nts,10) + "  " + QString::number(negative_sawtooth,10) + "  " + status);

    int a=qrand()%(((20+1)-0)+0);
    count= (200+a);
   // ui->label->setText(QString::number(200+a));


    ui->lbLCD->setText(QString::number(count,'f',2) + " ns");

    SaveData();

}

void Dialog::Ha_Data(QByteArray Ha)
{

//154 Bytes

    quint8 SAT_ID;
    // Start @ @ H a Data:   0,1,2,3
    // Date  m d y y Data:   4,5,6,7
    GPSdate.setDate((Ha.at(6)<<8 & 0xFF00) | (Ha.at(7) & 0x00FF),Ha.at(4),Ha.at(5));
    // Time h m s    Data:   8,9,10
    GPStime.setHMS(Ha.at(8),Ha.at(9),Ha.at(10),0);
    // nanoSeconds   Data:   11,12,13,14
    ///////////////////////////////////
    // Latitude FS   Data:   15,16,17,18
    // Longitud FS   Data:   19,20,21,22
    // GPS Height FS Data:   23,24,25,26
    // MSL Height FS Data:   27,28,29,30
    ///////////////////////////////////
    // Latitud AU    Data:   31,32,33,34
    rawpos.resize(12);
    latitudAU= (Ha.at(31) << 24 & 0xFF000000) | (Ha.at(32) << 16 & 0x00FF0000) | (Ha.at(33) << 8 & 0x0000FF00)| (Ha.at(34) & 0x000000FF);
    rawpos[0]=Ha.at(31);
    rawpos[1]=Ha.at(32);
    rawpos[2]=Ha.at(33);
    rawpos[3]=Ha.at(34);
    latitud=(double)latitudAU/3600000;
    // Longitud AU   Data:   35,36,37,38
    longitudAU=(Ha.at(35) << 24 & 0xFF000000) | (Ha.at(36) << 16 & 0x00FF0000) | (Ha.at(37) << 8 & 0x0000FF00)| (Ha.at(38) & 0x000000FF);
    rawpos[4]=Ha.at(35);
    rawpos[5]=Ha.at(36);
    rawpos[6]=Ha.at(37);
    rawpos[7]=Ha.at(38);
    longitud=(double)longitudAU/3600000;
    // GPS Height AU Data:   39,40,41,42
    heightAU=(Ha.at(39) << 24 & 0xFF000000) | (Ha.at(40) << 16 & 0x00FF0000) | (Ha.at(41) << 8 & 0x0000FF00)| (Ha.at(42) & 0x000000FF);
    rawpos[8]=Ha.at(39);
    rawpos[9]=Ha.at(40);
    rawpos[10]=Ha.at(41);
    rawpos[11]=Ha.at(42);
    altitud = (double)heightAU/100;
    // MSL Height AU Data:   43,44,45,46
    // Speed 3D      Data:   47,48
    // Speed 2D      Data:   49,50
    // Heading 2D    Data:   51,52
    // Geometry      Data:   53,54
    // Satellite     Data:   55,56
    nvs=Ha.at(55);     //Number of visible satellites  0...12
    nts=Ha.at(56);     //Number of tracked satellites  0...12
    //Satellites    Data:   57-128
    for(int i=0 ; i <12 ; i++)
    {
         SAT_ID=Ha.at(57+i*6); //63
         //Validar que solo vea GPS
         if (SAT_ID < 33){
         SVID[SAT_ID].mode=Ha.at(58+i*6); //64
         SVID[SAT_ID].signal=Ha.at(59+i*6);
         SVID[SAT_ID].IODE=Ha.at(60+i*6);
         SVID[SAT_ID].status=(Ha.at(61+i*6)<<8 & 0xFF00) | (Ha.at(62+i*6) & 0x00FF);
      /*  qDebug() << "SatNum"  << QString::number(i+1, 10) <<  QString::number(SVID[i].mode, 10) <<
                      QString::number(SVID[i].signal, 10) <<
                       QString::number(SVID[i].IODE, 10) << endl;*/
    }
    }


    // Receiver Status ss:   129,130
    receiver_status= (Ha.at(129)<<8 & 0xFF00) | (Ha.at(130) & 0x00FF);
    ReceiverStatus(receiver_status);
    // Reserved      Data:   131,132
    // Oscillator and Clock Parameters
    // Clock Bias cc Data:   133,134
    // OscOffset ooooData:   135,136,137,138
    // Temperature   Data:   139,140
    // TimeModeUTC u Data:   141
    // GMTOffset shm Data:   142,143,144
    // IDstring      Data:   145,146,147,148,149,150
    ID.append(Ha.at(145));ID.append(Ha.at(146));ID.append(Ha.at(147));ID.append(Ha.at(148));ID.append(Ha.at(149));ID.append(Ha.at(150));
    // Stop  C,CR,LF Data:   151,152,153
    // Print Debugs
    // qDebug() << "Ha Command Raw Data"   << Ha.size() << Ha.toHex() << endl;
    // qDebug() << "Date & Time : "     << GPSdate.toString() << "," << GPStime.toString() << endl;
    // qDebug() << "Position (Lat,Lon,Alt): "   << latitud << "," << longitud << "," << height << endl;
    // qDebug() << "Satellites (Visible, Tracked): "  << QString::number(nvs, 10) << "," << QString::number(nts, 10)<< endl ;
    // qDebug() << "ID" << ID << endl;
}

void Dialog::Hn_Data(QByteArray Hn)
{
    // 78 Bytes
    quint8 SAT_ID;
    // Start @ @ H n Data:   0,1,2,3
    pulse_status=Hn.at(4); // 0 = off; 1 = on
    PPS_sync=Hn.at(5);
    TimeRAIM_solution=Hn.at(6);
    TimeRAIM_status=Hn.at(7);
    TimeRAIM_svid=(Hn.at(8) << 24 & 0xFF000000) | (Hn.at(9) << 16 & 0x00FF0000) | (Hn.at(10) << 8 & 0x0000FF00)| (Hn.at(11) & 0x000000FF);
    time_solution=(Hn.at(12)<<8 & 0xFF00) | (Hn.at(13) & 0x00FF);
    last_negative_sawtooth=negative_sawtooth;  // Guardo el anterior
    negative_sawtooth=Hn.at(14);               // Actualizo el sawtooth

    // Satellite data are from byte 15
    for(int i=0 ; i < 12 ; i++)
    {
        SAT_ID=Hn.at(15+i*5); //15
        if (SAT_ID < 33){
            SVID[SAT_ID].fractional_GPS_time=(Hn.at(16+i*5) << 24 & 0xFF000000) | (Hn.at(17+i*5) << 16 & 0x00FF0000) | (Hn.at(18+i*5) << 8 & 0x0000FF00)| (Hn.at(19+i*5) & 0x000000FF);
     //   qDebug() << SAT_ID << SVID[SAT_ID].mode << SVID[SAT_ID].fractional_GPS_time;
        }
    }

//    //Print Debugs
//        if(!pulse_status){
//            qDebug() << "Pulse Status: OFF";
//        }
//        else{
//            qDebug() << "Pulse Status: ON";
//        }
//        if(!PPS_sync){
//            qDebug() << "Pulse Sync: UTC";
//        }
//        else{
//            qDebug() << "Pulse Sync: GPS";
//        }
//        qDebug() << "T-RAIM solution:" << QString::number(TimeRAIM_solution);
//        qDebug() << "T-RAIM status:" << QString::number(TimeRAIM_status);
//        qDebug() << "T-RAIM SVID:" << QString::number(TimeRAIM_svid,16);
//        qDebug() << "1 sigma accuracy:" << QString::number(time_solution);
//        qDebug() << "Negative Sawtooth" << QString::number(negative_sawtooth) << endl;
}

void Dialog::Bb_Data(QByteArray Bb)
{
    // 92 Bytes
    quint8 SAT_ID;
    // quint8  number_sats;
    // Start @ @ B b Data:   0,1,2,3
    // number_sats = Bb.at(4);
    // Satellite data are from byte 5 to 89
    for(int i=0 ; i < 12 ; i++)
    {
         SAT_ID=Bb.at(5+i*7); // 63
         if (SAT_ID < 33){
         SVID[SAT_ID].Doppler=(Bb.at(6+i*7)<<8 & 0xFF00) | (Bb.at(7+i*7) & 0x00FF);
         SVID[SAT_ID].elevation=Bb.at(8+i*7);
         SVID[SAT_ID].azimuth=(Bb.at(9+i*7)<<8 & 0xFF00) | (Bb.at(10+i*7) & 0x00FF);
         SVID[SAT_ID].sat_health=Bb.at(11+i*7);
         }
    }
}

//Send GPS commands
void Dialog::sendcommand(unsigned char *gpscommand, quint16 size, quint16 response)
{   //
    serialData.clear();         // clear received data buffer
    response_lenght=response;   // expected response length

    for (quint16 i=0; i < size; i++)
    {
        GPS->putChar(gpscommand[i]);

    }

}

void Dialog::SendPosition()
{
    // open the position file and send it to the receiver'
            QFile file(config_path + "/binary.pos");

            if (!file.open(QFile::ReadOnly))
            {
                qDebug() << "File not open" << endl;
            }
            else
            {
                QByteArray Position = file.readAll();
                qDebug() << "Position" << Position << endl;
                qDebug() << "Position size" << Position.size() << endl;
                file.close();

                quint8 checksum = 0x32;          // calculate checksum
                GPS->putChar('@');
                GPS->putChar('@');
                GPS->putChar(0x41);
                GPS->putChar(0x73);

                serialData.clear();   // clear received data buffer
                response_lenght=20;   // expected response length
            for (quint16 i=0; i < Position.size(); i++)
            {
                GPS->putChar(Position.at(i) & 0x00FF);
                checksum = checksum ^ Position.at(i);
            }

            GPS->putChar(0x00);
            GPS->putChar(checksum);
            GPS->putChar(0x0D);
            GPS->putChar(0x0A);
            }


}

void Dialog::SendPositionHold()
{
    //  @@Gd  Set Position Hold
    static unsigned char Gd[]={0x40, 0x40, 0x47, 0x64, 0x01, 0x22, 0x0D, 0x0A};
    sendcommand(Gd,sizeof(Gd),8);

}

void Dialog::ReceiverStatus(quint16 rs)
{

   // qDebug() << "Status" << QString::number(rs,16) << endl;
    //Test Bits 13-15:
    switch((rs >> 13) & 0x0007)
    {
        case 0x00: status="Reserved";break;
        case 0x01: status="Reserved";break;
        case 0x02: status="Bad Geometry";break;
        case 0x03: status="Adquiring Satellites";break;
        case 0x04: status="Position Hold";break;
        case 0x05: status="Propagate Mode";break;
        case 0x06: status="2D Fix";break;
        case 0x07: status="3D Fix";break;
    }
    //Bits 11-12: Reserved

    //Test Bit10: Narrow band tracking mode
    if((rs&0x0400)){
        status=status+" Narrow Band";
    }
    //Test Bit9: Fast Acquisition Position
    if((rs&0x0200)){
        status=status+" Fast Acq";
    }
    //Test Bit8: Filter Reset To Raw GPS Solution
    if((rs&0x0100)){
        status=status+" Filter Reset";
    }

    //Test Bit7: Cold Start
    if((rs&0x0080)){
        status=status+" Cold Start";
    }
    //Test Bit6: Diferential Fix
    if((rs&0x0040)){
        status=status+" Differential Fix";
    }
    //Test Bit5: Position Lock
    if((rs&0x0020)){
        status=status+" Position Lock";
    }
    //Test Bit4: Autosurvey Mode
    if((rs&0x0010)){
        status="Survey Mode";
    }
    //Test Bit3: Insufficient Visible Satellites
    if((rs&0x0008)){
        status=status+" Insuf V. Sat";
    }

    //Test Bits 2-1:
    switch((rs >> 1) & 0x0003)
    {
        case 0x00: /*status=status+" Ant OK"*/;break;
        case 0x01: status="Ant OC";break;
        case 0x02: status="Ant UC";break;
        case 0x03: status="Ant NV";break;
    }
    //Test Bit0: Code Location
    if((rs&0x0001)){
       // status=status+" Internal";
    }else{
       // status=status+" External";
    }


}

void Dialog::ReadSettings()
{
    QString iniFileName=config_path + "/config.ini";
    // Load Application params from ini file
    QSettings settings( iniFileName, QSettings::IniFormat );

    settings.beginGroup("PORTS");
    GPS_port_name = settings.value("GPS").toString();
    if (GPS_port_name != ""){
        GPS_is_available=true;
    }
    TIC_port_name = settings.value("TIC").toString();
    if (TIC_port_name != ""){
        TIC_is_available=true;
    }
    settings.endGroup();

    settings.beginGroup("DELAYS");
    int_dly = settings.value("INT").toDouble();
    cbl_dly = settings.value("CAB").toDouble();
    ref_dly = settings.value("REF").toDouble();
//          qDebug() << "INT_DLY = " << QString::number(int_dly,'f',2)
//                   << "CBL_DLY = " << QString::number(cbl_dly,'f',2)
//                   << "REF_DLY = " << QString::number(ref_dly,'f',2)
//                   << endl;
    settings.endGroup();

    settings.beginGroup("CONTACT");
    LAB = settings.value("LAB").toString();
    COM = settings.value("COM").toString();
    REF = settings.value("REF").toString();
    settings.endGroup();

    settings.beginGroup("EXTRA");
    EXT = settings.value("EXT").toString();
    IP  = settings.value("IP").toString();
    settings.endGroup();

}

void Dialog::SettoDefaults()
{
    //@@Cf Set to Defaults
    static unsigned char Cf[]={0x40, 0x40, 0x43, 0x66, 0x25, 0x0D, 0x0A};
    sendcommand(Cf,sizeof(Cf),7);
}

void Dialog::EnableTRAIM()
{

//    TIME RAIM SELECT MESSAGE
//    @@Ge
//    Query
//    0x40 0x40 0x47 0x65 0xFF 0xDD 0x0D 0x0A
//    Disable TRAIM
//    0x40 0x40 0x47 0x65 0x00 0x22 0x0D 0x0A
//    Enable TRAIM
//    0x40 0x40 0x47 0x65 0x01 0x23 0x0D 0x0A
    static unsigned char Ge[]={0x40, 0x40, 0x47, 0x65, 0x01, 0x23, 0x0D, 0x0A};
    sendcommand(Ge,sizeof(Ge),8);
}

void Dialog::StartPolling()
{
    //@@Hn Time RAIM Status Message
     static unsigned char Bb[]={0x40, 0x40, 0x42, 0x62, 0x01, 0x21, 0x0D, 0x0A};
     static unsigned char Ha[]={0x40, 0x40, 0x48, 0x61, 0x01, 0x28, 0x0D, 0x0A};
     static unsigned char Hn[]={0x40, 0x40, 0x48, 0x6E, 0x01, 0x27, 0x0D, 0x0A};
    //Send Triple Command
     sendcommand(Bb,sizeof(Bb),0);
     sendcommand(Ha,sizeof(Ha),0);
     sendcommand(Hn,sizeof(Hn),0);
}

void Dialog::StopPolling()
{
   //@@Hn Time RAIM Status Message
    static unsigned char Bb[]={0x40, 0x40, 0x42, 0x62, 0x00, 0x20, 0x0D, 0x0A};
    static unsigned char Ha[]={0x40, 0x40, 0x48, 0x61, 0x00, 0x29, 0x0D, 0x0A};
    static unsigned char Hn[]={0x40, 0x40, 0x48, 0x6E, 0x00, 0x26, 0x0D, 0x0A};
   //Send Triple Command
    sendcommand(Bb,sizeof(Bb),0);
    sendcommand(Ha,sizeof(Ha),0);
    sendcommand(Hn,sizeof(Hn),0);
}

void Dialog::PPSOneSat()
{
//    1PPS CONTROL MESSAGE
//    @@Gc
//    1PPS Disabled
//    0x40 0x40 0x47 0x63 0x00 0x24 0x0D 0x0A
//    1PPS Always
//    0x40 0x40 0x47 0x63 0x01 0x25 0x0D 0x0A
//    1PPS Active at least one satellite
//    0x40 0x40 0x47 0x63 0x02 0x26 0x0D 0x0A
//    1PPS Active when T-RAIM conditions are met
//    0x40 0x40 0x47 0x63 0x03 0x27 0x0D 0x0A

    static unsigned char Gc[]={0x40, 0x40, 0x47, 0x63, 0x02, 0x26, 0x0D, 0x0A};
    sendcommand(Gc,sizeof(Gc),8);

}

void Dialog::SurveyPosition()
{
    static unsigned char Gd[]={0x40, 0x40, 0x47, 0x64, 0x03, 0x20, 0x0D, 0x0A};   //@@Gd 0x03 autosurvey
    sendcommand(Gd,sizeof(Gd),8);
}

quint32 Dialog::JulianDate(QDate MJD)
{
    // This routine calculate the Modified Julian Data
    // input:    QDate
    // output:   Quint32 MJD
    return MJD.toJulianDay()-2400001;
}

void Dialog::LLAtoECEF(double lat, double lon, double h)
{
//    The basic formulas for converting from latitude, longitude, altitude
//    (above reference ellipsoid) to Cartesian ECEF are given in the
//    Astronomical Almanac in Appendix K.  They depend upon the following
//    quantities:

//         a   the equatorial earth radius
//         f   the "flattening" parameter ( = (a-b)/a ,the ratio of the
//             difference between the equatorial and polar radio to a;
//             this is a measure of how "elliptical" a polar cross-section
//             is).

//    The eccentricity e of the figure of the earth is found from

//        e^2 = 2f - f^2 ,  or  e = sqrt(2f-f^2) .

//    For WGS84,

//             a   = 6378137 meters
//           (1/f) = 298.257224

//    (the reciprocal of f is usually given instead of f itself, because the
//    reciprocal is so close to an integer)

//    Given latitude (geodetic latitude, not geocentric latitude!), compute

//                                      1
//            C =  ---------------------------------------------------
//                 sqrt( cos^2(latitude) + (1-f)^2 * sin^2(latitude) )

//    and
//            S = (1-f)^2 * C .

//    Then a point with (geodetic) latitude "lat," longitude "lon," and
//    altitude h above the reference ellipsoid has ECEF coordinates

//           x = (aC+h)cos(lat)cos(lon)
//           y = (aC+h)cos(lat)sin(lon)
//           z = (aS+h)sin(lat)



    double cosLat = qCos(lat * M_PI / 180.0);
    double cosLon = qCos(lon * M_PI / 180.0);
    double sinLat = qSin(lat * M_PI / 180.0);
    double sinLon = qSin(lon * M_PI / 180.0);

    double a = 6378137;
    double f= 1.0/298.257224;
    double C=1.0/(qSqrt((cosLat*cosLat)+((1.0-f)*(1.0-f)*sinLat*sinLat)));
    double S=(1.0-f)*(1.0-f)*C;


    ECEF_X = (a * C + h) * cosLat * cosLon;
    ECEF_Y = (a * C + h) * cosLat * sinLon;
    ECEF_Z = (a * S + h) * sinLat;


    qDebug() << "lat" << QString::number(lat,'f',6) << "°" <<
                "lon" << QString::number(lon,'f',6) << "°" <<
                "alt" << QString::number(h,'f',2) << "m" <<
                endl;


    qDebug() << "x" << QString::number(ECEF_X,'f',2) << "m" <<
                "y" << QString::number(ECEF_Y,'f',2) << "m" <<
                "z" << QString::number(ECEF_Z,'f',2) << "m" <<
                endl;
//    http://www.oc.nps.edu/oc2902w/coord/llhxyz.htm
}

void Dialog::SaveData()
{
    //  this flag is false unless a new file is started later in the routine
    QString oldname=namefile;
    QString extension="." + EXT; // filename extension

    //  define file name
    namefile= QString::number(JulianDate(GPSdate))  + extension;

    if (namefile != oldname)
    {
        QString filename= data_path + "/" + namefile;
        QString filename_one= data_path + "/" + "ONE_"+namefile;
        QFile file(filename);
        QFile file_one(filename_one);
    //  if the file is not found, use the defaults defined here
        if (!QFile(filename).exists()) {
            if (!file.open(QIODevice::WriteOnly | QIODevice::Text)){
                  qDebug() << "no data file" <<endl;
              }
             else{
                LLAtoECEF(latitud,longitud,altitud);
                QTextStream outStream(&file);
                //default settings
                outStream << "#LAB = " << LAB << endl;                 // Device number
                outStream << "#ECEF" << endl;
                outStream << "#X = " << QString::number(ECEF_X,'f',2) << " m (GPS)" << endl;            // X
                outStream << "#Y = " << QString::number(ECEF_Y,'f',2) << " m (GPS)" << endl;            // Y
                outStream << "#Z = " << QString::number(ECEF_Z,'f',2) << " m (GPS)" << endl;            // Z
                outStream << "#WGS84" << endl;            //
                outStream << "#LAT = " << QString::number(latitud, 'g', 10) << " ° (GPS)" << endl;            // X
                outStream << "#LON = " << QString::number(longitud, 'g', 10) << " ° (GPS)" << endl;            // Y
                outStream << "#ALT = " << QString::number(altitud,'g',10) << " m (GPS)" << endl;            // Z
                outStream << "#COMMENTS = " << COM << endl;            //
                outStream << "#INT DLY = " << QString::number(int_dly,'f',2) << " ns" << endl;
                outStream << "#CAB DLY = " << QString::number(cbl_dly,'f',2) << " ns" << endl;
                outStream << "#REF DLY = " << QString::number(ref_dly,'f',2) << " ns" << endl;
                outStream << "#REF = " << REF << endl;            //
                outStream <<  endl;            //
                outStream << "TIME,DIFF,SAWTOOTH" << endl;            //
                file.flush();
                file.close();
             }
        }

    //  Creado del archivo por minuto
        if (!QFile(filename_one).exists()) {
            if (!file_one.open(QIODevice::WriteOnly | QIODevice::Text)){
                  qDebug() << "no data file" <<endl;
              }
             else{
                LLAtoECEF(latitud,longitud,altitud);
                QTextStream outStream(&file_one);
                //default settings
                outStream << "#LAB = " << LAB << endl;                 // Device number
                outStream << "#ECEF" << endl;
                outStream << "#X = " << QString::number(ECEF_X,'f',2) << " m (GPS)" << endl;            // X
                outStream << "#Y = " << QString::number(ECEF_Y,'f',2) << " m (GPS)" << endl;            // Y
                outStream << "#Z = " << QString::number(ECEF_Z,'f',2) << " m (GPS)" << endl;            // Z
                outStream << "#WGS84" << endl;            //
                outStream << "#LAT = " << QString::number(latitud, 'g', 10) << " ° (GPS)" << endl;            // X
                outStream << "#LON = " << QString::number(longitud, 'g', 10) << " ° (GPS)" << endl;            // Y
                outStream << "#ALT = " << QString::number(altitud,'g',10) << " m (GPS)" << endl;            // Z
                outStream << "#COMMENTS = " << COM << endl;            //
                outStream << "#INT DLY = " << QString::number(int_dly,'f',2) << " ns" << endl;
                outStream << "#CAB DLY = " << QString::number(cbl_dly,'f',2) << " ns" << endl;
                outStream << "#REF DLY = " << QString::number(ref_dly,'f',2) << " ns" << endl;
                outStream << "#REF = " << REF << endl;            //
                outStream <<  endl;            //
                outStream << "MINUTE,TIME,DIFF,SECONDS" << endl;            //
                file_one.flush();
                file_one.close();
             }
        }



    }
    //  Guardado por segundo
        QString filename= data_path + "/" + namefile;
        QFile file(filename);
        file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text);
        QTextStream outStream(&file);
        outStream << GPStime.toString("hhmmss")
                  << ","
                  << QString::number(count,'f',2)
                  << ","
                  << QString::number(last_negative_sawtooth)
                  << endl;
        file.flush();
        file.close();

        seconds=seconds+1;
        count_one=count_one+count+last_negative_sawtooth;
//        QString a;
//        a.append("mosquitto_pub");
//        a.append(" -h ");
//        a.append(IP);
//        a.append(" -t ");
//        a.append("DATA");
//        a.append(" -m ");
//        a.append(EXT + "," + QString::number(minutes) + "," + QString::number(count));
//       // qDebug()<< a;

//       mosquitto->startDetached(a);
//       a.detach();


if (GPStime.second()==59){

            count_one=count_one/seconds;

            minutes=(GPStime.hour()*60+GPStime.minute());

        //  Guardado por minuto
            QString filename_one= data_path + "/" + "ONE_" + namefile;
            QFile file_one(filename_one);
            file_one.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text);
            QTextStream outStream_one(&file_one);
            outStream_one << QString::number(minutes)
                      << ","
                      << GPStime.toString("hhmm") + "30"
                      << ","
                      << QString::number(count_one,'f',2)
                      << ","
                      << QString::number(seconds)
                      << endl;
            file_one.flush();
            file_one.close();


            QString a;
            a.append("mosquitto_pub");
            a.append(" -h ");
            a.append(IP);
            a.append(" -t ");
            a.append("DATA");
            a.append(" -m ");
            a.append(EXT + "," + QString::number(minutes) + "," + QString::number(count_one));
           // qDebug()<< a;

           mosquitto->startDetached(a);
           a.detach();


        // Actualizo el promedio por minuto
        ui->lbLCD_P->setText(QString::number(count_one,'f',2) + " ns");
      // Limpio las variables
        count_one=0;
        seconds=0;


}

}

void Dialog::on_btnSurvey_clicked()
{
   SurveyPosition();
}

void Dialog::on_btnReset_clicked()
{
    debug = "Send Reset";
    qDebug() << debug;
    ui->txtDBG->setText(debug);
    SettoDefaults();
}

void Dialog::SetConstellationMode()
{
    // @@Sc Set Constellation Mode
    // Query
    // 0x40 0x40 0x53 0x63 0x00 0x30 0x0D 0x0A
    // Set Only GPS
    // 0x40 0x40 0x53 0x63 0x01 0x31 0x0D 0x0A
    static unsigned char Sc[]={0x40, 0x40, 0x53, 0x63, 0x01, 0x31, 0x0D, 0x0A};
    sendcommand(Sc,sizeof(Sc),8);
}

void Dialog::SetDateTimePPSAlignment()
{
   // @@St Set Date/Time/PPS Alignment
   // This command sets or queries the time & 1PPS alignment source.
   // Query
   // 0x40 0x40 0x53 0x74 0x00 0x27 0x0D 0x0A
   // Set to UTC(USNO) with leap seconds
   // 0x40 0x40 0x53 0x74 0x02 0x25 0x0D 0x0A
    static unsigned char St[]={0x40, 0x40, 0x53, 0x74, 0x02, 0x25, 0x0D, 0x0A};
    sendcommand(St,sizeof(St),8);
}

void Dialog::SavePosition()
{
    //Position file creation
    QFile file(config_path + "/binary.pos");

    if (!file.open(QFile::WriteOnly))
    {
        qDebug() << "File not open" <<endl;
    }
    else
    {
        file.write(rawpos);     // correct
        file.flush();
        file.close();
    }
}

/*
// Extendend SSR-M8T
GNSS Receiver Type
@@Sx
0x40 0x40 0x53 0x78 0x2B 0x0D 0x0A
01 00000001 - GPS
02 00000010 - GLONASS
04 00000100 - Galileo
08 00001000 - BeiDou
10 00010000 - QZSS
20 00100000 - other 1
40 01000000 - other 2
80 10000000 - SBAS


@@St Set Date/Time/PPS Alignment
This command sets or queries the time & 1PPS alignment source.
Query
0x40 0x40 0x53 0x74 0x00 0x27 0x0D 0x0A
Set to UTC(USNO) with leap seconds
0x40 0x40 0x53 0x74 0x02 0x25 0x0D 0x0A


@@Sa Report Satellite Tracking Information
This command queries detailed satellite tracking information (up to 24 satellites)
@@SaxC<CR><LF>
Poll
0x40 0x40 0x53 0x61 0x00 0x32 0x0D 0x0A
One Second
0x40 0x40 0x53 0x61 0x01 0x33 0x0D 0x0A


@@Sp Report Current Number of Leap Seconds
This command queries the current number of leap seconds
Query Current Number of Leap Seconds
@@SpC<CR><LF>
0x40 0x40 0x53 0x70 0x23 0x0D 0x0A


@@So Configure @@Ha/Hn/Bb Message
(Future enhancement - not implemented at this time.)
This command configures which satellites the @@Ha, @@Hn, and @@Bb
messages report.
Command to configure @@Ha/Hn/Bb Message
@@SoxC<CR><LF>
0x40 0x40 0x53 0x6F 0xFF 0xC3 0x0D 0x0A


@@Sm Save configuration to non-volatile memory
Command to save all settings to non-volatile memory
@@SmbC<CR><LF>
b= 0x01 or 0xA5 to save all data (all else = nothing saved)
0x40 0x40 0x53 0x6D 0x01 0x3F 0x0D 0x0A
*/

void Dialog::on_btnConfig_clicked()
{
    SetConstellationMode();
}

void Dialog::on_btnStartPoll_clicked()
{
    StartPolling();
}

void Dialog::on_btnStopPoll_clicked()
{
    StopPolling();
}

void Dialog::on_btnSavePosition_clicked()
{
    SavePosition();
}

void Dialog::on_btnSendPosition_clicked()
{
    SendPosition();
}

void Dialog::on_btnFuegoNuevo_clicked()

{

   if (debug_bool)
   {
    ui->btnConfig->setVisible(false);
    ui->btnReset->setVisible(false);
    ui->btnReboot->setVisible(false);
    ui->btnSendPosition->setVisible(false);
    ui->btnStartPoll->setVisible(false);
    ui->btnStopPoll->setVisible(false);
    ui->btnSurvey->setVisible(false);
    ui->txtDBG->setVisible(false);
    debug_bool = false;
   }
   else
   {
   ui->btnConfig->setVisible(true);
   ui->btnReset->setVisible(true);
   ui->btnReboot->setVisible(true);
   ui->btnSendPosition->setVisible(true);
   ui->btnStartPoll->setVisible(true);
   ui->btnStopPoll->setVisible(true);
   ui->btnSurvey->setVisible(true);
   ui->txtDBG->setVisible(true);
   debug_bool= true;
   }
}

void Dialog::on_btnReboot_clicked()
{
    QString a;
    a.append("reboot");
//    a.append(" -h ");
//    a.append(IP);
//    a.append(" -t ");
//    a.append("DATA");
//    a.append(" -m ");
//    a.append(EXT + "," + QString::number(minutes) + "," + QString::number(count_one));
//   // qDebug()<< a;

   mosquitto->startDetached(a);
   a.detach();

}
